Team Name: Absolute Duo

Name: Darin Minamoto
UID: 704140102

Name: Kevin Tong
UID: 704161137

---------------------------------------------------------------------------------------

Debugging .jsp pages was challenging, though it was incredibly satisfying to see our webpage come together piece by piece.
package edu.ucla.cs.cs144;

public class Seller {
    public String s_userID;
    public String s_rating;

    public Seller(String userID, String rating) {
        s_userID = userID;
        s_rating = rating;
    }
}
Team Name: Absolute Duo

Name: Darin Minamoto
UID: 704140102

Name: Kevin Tong
UID: 704161137

---------------------------------------------------------------------------------------

Q1:
(4) -> (5) and (5) -> (6)

Q2:
ItemID, ItemName, and BuyPrice are all set at the item page within an http sesion. Once this is done, BuyPrice is associated with the item through the session, which guarantees that the item's BuyPrice is correct.